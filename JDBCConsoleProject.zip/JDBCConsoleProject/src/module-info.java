/**
 * 
 */
/**
 * 
 */
module JDBCConsoleProject {
	requires java.sql;
}